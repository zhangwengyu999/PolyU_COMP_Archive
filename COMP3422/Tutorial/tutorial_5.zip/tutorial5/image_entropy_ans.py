import cv2
import numpy as np
import matplotlib.pyplot as plt


if __name__ == '__main__':
    img = cv2.imread('example_image.jpeg')
    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    plt.imshow(img, cmap='gray')

    H, W = img.shape
    color, c_freq = np.unique(img, return_counts=True)
    c_prob = c_freq / (H * W)
    img_entropy = (- c_prob * np.log2(c_prob)).sum()
    print(f"The calculated Entropy is {img_entropy}")
