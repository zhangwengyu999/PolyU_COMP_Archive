# The pre-defined huffman dict
huffman_code_dict = {
    'E': '00', 'B': '010', 'D': '011', 'A': '10', 'C': '11'
}


if __name__ == '__main__':
    compressed_code = '100101101100'

    # create the inverse map
    code_to_char = {str(v): k for k, v in huffman_code_dict.items()}

    result = ''
    target = compressed_code
    tmp = ''
    while len(target) > 0:
        tmp += target[0]
        target = target[1:]
        if tmp in code_to_char:
            result += code_to_char[tmp]
            tmp = ''

    print(result)
