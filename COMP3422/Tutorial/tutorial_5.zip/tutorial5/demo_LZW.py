

def compress(uncompressed = 'bananabandan'):
    ## step 1: initial dictionary
    init_dic = {'a': 'a',
                'b': 'b',
                'd': 'd',
                'n': 'n'}

    ## step 2: compressing and updating dictionary
    dictionary = init_dic
    previous_str = ""
    compressed_result = []
    for i, current_char in enumerate(uncompressed):
        pre_cur = previous_str + current_char

        print(f"STEP {i}: -------------------------------------------, cur {current_char}")
        print(dictionary)
        print(f"previous_str: {previous_str}, ", end='')
        print(f"pre_cur: {pre_cur}, ", end='')

        if pre_cur in dictionary:
            previous_str = pre_cur
            print(f"compressed_result: {compressed_result}")
            print(f"remaining uncompressed: {uncompressed[i+1:]}")
        else:
            ## step 2.1: getting compressed code for previous str
            previous_str_code = dictionary[previous_str]
            compressed_result.append(previous_str_code)
            print(f"compressed_result: {compressed_result}")

            ## step 2.2: updating the dictionary.
            dictionary[pre_cur] = len(dictionary)
            previous_str = current_char
            print("updated dictionary: ", dictionary)
            print(f"remaining uncompressed: {uncompressed[i+1:]}")

    ## getting compressed code for the last previous str
    compressed_result.append(dictionary[previous_str])
    print("ITERATION END")
    print(compressed_result)

    print(dictionary)
    return compressed_result


def decompress(compressed):
    ## init dictionary
    init_dic = {'a': 'a',
                'b': 'b',
                'd': 'd',
                'n': 'n'}

    dictionary = init_dic
    prev_code = decompress_result = compressed.pop(0)
    for i, curr_code in enumerate(compressed):

        print(f"STEP {i}: -------------------------------------------, curr_code {curr_code}")
        print(dictionary)
        print(f"prev_code: {prev_code}, ", end='')

        ## decompressed
        if curr_code in dictionary:
            curr_code_decomp = dictionary[curr_code]
            print(f"curr_code_decomp: {curr_code_decomp}, ", end='')
        elif curr_code == len(init_dic):
            curr_code_decomp = prev_code + prev_code[0]
            print(f"curr_code_decomp: {curr_code_decomp}, ", end='')
        else:
            raise ValueError('Bad compressed code: %s' % curr_code)
        decompress_result += curr_code_decomp
        print(f"decompress_result: {decompress_result}")

        ## updating dictionary
        dictionary[len(dictionary)] = prev_code + curr_code_decomp[0]
        prev_code = curr_code_decomp
        print("updated dictionary: ", dictionary)
        print(f"remaining compressed: {compressed[i+1:]}")

    print(dictionary)
    return decompress_result

print(" ######################### COMPRESSION ########################## ")
compressed = compress('bananabandan')
print (compressed)
print("\n\n ######################### DECOMPRESSION ########################## ")
decompressed = decompress(compressed)
print (decompressed)