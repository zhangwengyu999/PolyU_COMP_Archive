import matplotlib.pyplot as plt
import numpy as np


def series_part(t, k):
    # TODO: Define the inside-summation series part here
    x = None
    return x


def series(t, K):
    # TODO: Define the series function here
    x = np.zeros_like(t)
    for k in range(K):
        x = None
    return x


if __name__ == '__main__':
    # you are going to visualize the provided audio signal
    # TODO: initialize the time space
    t = None

    # calculate the series result
    K = 50
    x = series(t, K)

    # TODO: plot the series
    pass

    plt.show()
