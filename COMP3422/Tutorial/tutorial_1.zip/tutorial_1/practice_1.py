even_sum = 0
for number in range(1, 11):
    if number % 2 == 0: ## even number
        even_sum += number
    else: ## odd number
        print('odd number', number)
print('sum of even numbers', even_sum)
