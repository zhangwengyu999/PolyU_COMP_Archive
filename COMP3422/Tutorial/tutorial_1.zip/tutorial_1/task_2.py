with open('fibonacci_n.txt') as f:
    nterms = int(f.readlines()[0])
print('nterms', nterms)

## calculate Fibonacci sequence
n1, n2 = 0, 1
count = 0
fibonacci_sequence = []
while count < nterms:
    fibonacci_sequence.append(n1)
    nth = n1 + n2
    # update values
    n1 = n2
    n2 = nth
    count += 1

with open('fibonacci_output.txt', 'w') as f:
    f.write('\n'.join(str(number) for number in fibonacci_sequence))