import cv2
image = cv2.imread('example_image.jpeg')
grayscale_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
cv2.imwrite('example_image_grayscale.jpeg', grayscale_image)