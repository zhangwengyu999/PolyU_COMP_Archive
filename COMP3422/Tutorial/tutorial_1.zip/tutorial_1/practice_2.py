with open('example.txt') as f:
    for line in f:
        print(line)