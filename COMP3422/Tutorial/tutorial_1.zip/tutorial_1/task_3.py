import cv2 
image = cv2.imread('example_image.jpeg')
image_with_border = cv2.copyMakeBorder(image, 20, 20, 20, 20, cv2.BORDER_CONSTANT, None, value = 0)
cv2.imwrite('example_image_with_border.jpeg', image_with_border)