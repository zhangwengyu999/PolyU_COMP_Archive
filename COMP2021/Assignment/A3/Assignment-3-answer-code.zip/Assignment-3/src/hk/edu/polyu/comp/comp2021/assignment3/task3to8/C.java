package hk.edu.polyu.comp.comp2021.assignment3.task3to8;

public class C extends B {
    public C(String name) {
        super(name + "C");  // Task 6
        this.name = name;
        System.out.println(/* Task 7 */ name);
    }

    public void sendMsg(String msg) {
        System.out.println(/* Task 8 */ name + msg);  // Remember that super.name is different from this.name?
    }
}
