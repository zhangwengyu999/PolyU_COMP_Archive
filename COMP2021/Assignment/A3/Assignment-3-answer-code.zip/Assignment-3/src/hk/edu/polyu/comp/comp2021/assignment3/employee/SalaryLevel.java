package hk.edu.polyu.comp.comp2021.assignment3.employee;

/**
 * Levels of salary.
 */
enum SalaryLevel {
    ENTRY(1), JUNIOR(1.25), SENIOR(1.5), EXECUTIVE(2);

    // Add missing code here.
    /**
     * Salary scale
     */
    private final double scale;

    public static final double BASE_SALARY = 2000.0;

    SalaryLevel(double scale) {
        this.scale = scale;
    }

    public double getScale() {
        return scale;
    }

    /**
     * Compute the salary as "scale * BASE_SALARY"
     * @return
     */
    public double salary() {
        return scale * BASE_SALARY;
    }

    /**
     * An overloaded version of "salary", which allows adding bonus salary by specified rate
     * @param bonusRate
     * @return normal salary + bonus salary
     */
    public double salary(double bonusRate) {
        return salary() * (bonusRate + 1);
    }
    // End missing code.
}