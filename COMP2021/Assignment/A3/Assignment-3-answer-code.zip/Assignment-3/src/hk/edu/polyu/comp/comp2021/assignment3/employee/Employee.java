package hk.edu.polyu.comp.comp2021.assignment3.employee;

/**
 * An employee in a company.
 */
public class Employee {
    /**
     * Name of the employee.
     */
    private final String name;

    /**
     * Level of salary of the employee.
     */
    private SalaryLevel salaryLevel;

    /**
     * Return the name of the employee.
     */
    public String getName() {
        return name;
    }

    /**
     * Return the salary level of the employee.
     */
    public SalaryLevel getSalaryLevel() {
        return salaryLevel;
    }

    /**
     * Set the salary level.
     */
    public void setSalaryLevel(SalaryLevel salaryLevel) {
        this.salaryLevel = salaryLevel;
    }

    /**
     * Initialize an employee object.
     */
    public Employee(String name, SalaryLevel level) {
        // Add missing code here.
        this.name = name;
        this.salaryLevel = level;
        // End missing code.
    }

    /**
     * Return the salary of the employee.
     */
    public double salary() {
        // The salary of an employee is computed as the multiplication
        // of the base salary (2000.0) and the scale of the employee's salary level.

        // Add missing code here.
        /*
        As an "Employee" object (not in reality), we don't care how the salary is calculated.
        Therefore, we decouple the salary calculation from "Employee" and implement it in "SalaryLevel".
        As a result, if I want to change the salary calculation, I only need to change "SalaryLevel".

        Conclusion: it is a good practice to avoid mixing different functionalities in one single class.
        */
        return salaryLevel.salary();
        // End missing code.
    }

    /**
     * Base salary of all employees.
     */
    public static final double BASE_SALARY = 2000.0;

}
