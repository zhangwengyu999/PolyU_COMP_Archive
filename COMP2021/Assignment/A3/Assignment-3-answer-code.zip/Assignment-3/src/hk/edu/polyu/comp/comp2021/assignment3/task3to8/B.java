package hk.edu.polyu.comp.comp2021.assignment3.task3to8;

public class B extends A {
    public String name;

    public B(String name) {
        super(name + "B");  // Task 3
        this.name = name;
        System.out.println(/* Task 4 */ name);
    }

    public void sendMsg(String msg) {
        System.out.println(/* Task 5 */ super.name + msg);  // super.name is not this.name because you can't override fields.
    }
}

