package hk.edu.polyu.comp.comp2021.assignment3.task3to8;

public class A {
    public String name;

    public A(String name) {
        this.name = name;
        System.out.println(this.name);
    }

    public void sendMsg(String msg) {
        System.out.println(this.name + msg);
    }
}
