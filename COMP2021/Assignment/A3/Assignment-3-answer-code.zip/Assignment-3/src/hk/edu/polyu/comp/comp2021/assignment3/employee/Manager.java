package hk.edu.polyu.comp.comp2021.assignment3.employee;

/**
 * A manager in a company.
 */
public class Manager extends Employee {
    private double bonusRate;

    /**
     * Initialize a manager object.
     */
    public Manager(String name, SalaryLevel level, double bonusRate) {
        // Add missing code here.
        super(name, level);  // You must call super constructor first.
        /*
        "name" and "salaryLevel" are initialized by the super constructor,
        so we only need to initialize "bonusRate" here.

        Conclusion: "mind your own business" - do your job in your class,
        let the super class do what it has to do. You must make clear the
        responsibility, i.e., the scope, of the class you're implementing.
        */
        this.bonusRate = bonusRate;
        // End missing code.
    }

    public double getBonusRate() {
        return bonusRate;
    }

    public void setBonusRate(double bonusRate) {
        this.bonusRate = bonusRate;
    }

    // Override method Employee.salary to calculate the salary of a manager.
    // The salary of a manager is computed as the multiplication
    // of his/her regular salary as an employee and his/her bonusRate plus 1.
    public double salary() {
        // Add missing code here.
        // Again, we don't want to mix the salary calculation with the "Manager".
        return getSalaryLevel().salary(getBonusRate());
        // End missing code.
    }

}
