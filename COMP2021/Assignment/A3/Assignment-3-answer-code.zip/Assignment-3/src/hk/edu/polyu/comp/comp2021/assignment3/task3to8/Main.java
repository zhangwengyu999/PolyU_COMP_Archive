package hk.edu.polyu.comp.comp2021.assignment3.task3to8;

public class Main {
    public static void main(String[] args) {
        A a = new A("a");  // Obviously, "A"'s constructor prints one line - already prints "a", no need for change.
        /*
        Prints two lines, because "B"'s constructor calls "A"'s constructor and then prints the second line.

        Objective: make it firstly prints "bB", and then "b".
         */
        B b = new B("b");
        /*
        Prints three lines, because "C" calls "B", and "B" calls "A".

        Objective: make it prints "cCB", and then "cC", finally "c".
         */
        C c = new C("c");
        a.sendMsg("0");  // Obviously, prints "a0".
        a = b;
        a.sendMsg("1");  // Obviously, prints "bB1".
        a = c;
        a.sendMsg("2");  // Obviously, prints "c2".
        /*
        a
        bB
        b
        cCB
        cC
        c
        a0
        bB1
        c2
         */
    }
}
