package hk.edu.polyu.comp.comp2021.assignment4.compset;

import java.util.ArrayList;
import java.util.List;

class CompSet<T> {

    /** Each CompSet uses at most 1023 buckets.   */
    private static final int NUBMER_OF_BUCKETS = 1023;

    /**
     * An array of buckets as the storage for each set.
     *
     * The protocol:
     *
     * 1. It is final (and is initialized by constructor only)
     * 2. It has a constant size `NUBMER_OF_BUCKETS`
     * 3. The bucket, which is of type `List<T>`, is nullable
     * 4. A null bucket is equivalent to a non-null but empty bucket (empty list)
     * 5. You don't have to replace an empty bucket (empty list) with a `null`
     * 6. The bucket is lazily initialized upon new element is added to the bucket
     */
    private final List<T>[] storage;

    public CompSet() {
        // Add missing code here
        /* Allocate empty slots for 1023 buckets **without** initializing each element.
        Therefore, `storage` is now an array of 1023 `null`s.

        Alternatively, you may initialize all these 1023 elements as empty lists (`ArrayList`s for example).
        If you choose to do so, however, you also need to make appropriate changes to the logics of other methods.
         */
        storage = new List[NUBMER_OF_BUCKETS];
        // End missing code
    }

    /**
     * Initialize 'this' with the unique elements from 'elements'.
     * Throw IllegalArgumentException if 'elements' is null.
     */
    public CompSet(List<T> elements) {
        // Add missing code here
        this();  // Delegate the actual initialization
        if (elements == null) {
            throw new IllegalArgumentException("Cannot add initial elements from a null list");
        }
        // All we need to do after `this()` call, is to add the `elements` to `this`
        for (T element : elements) {
            add(element);
        }
        // End of missing code
    }

    /**
     * Get the total number of elements stored in 'this'.
     */
    public int getCount() {
        // Add missing code here
        // The total number of elements should be the sum of the number of elements in all buckets
        int sum = 0;
        for (List<T> bucket : storage) {
            if (bucket != null) {  // Don't forget protocol 3 and 4
                sum += bucket.size();
            }
        }
        return sum;
        // End missing code
    }

    public boolean isEmpty() {
        // Add missing code here
        // Obviously this is just a shortcut of `getCount() == 0`
        return getCount() == 0;
        // End missing code
    }

    /**
     * Whether 'element' is contained in 'this'?
     */
    public boolean contains(T element) {
        // Add missing code here
        if (
                element == null ||  // Because we don't accept null element
                isEmpty()  // Obvious, isn't it?
        ) return false;
        // Similar to how we do in `add`, but we are checking the existance
        int bucketIndex = getIndex(element);  // Which bucket the element belongs to?
        List<T> bucket = storage[bucketIndex];
        if (bucket == null) return false;  // According to protocol 4, a null bucket is effectively an empty bucket
        // Since we have found the bucket, just return:
        return bucket.contains(element);
        // Alternatively, just return `bucket != null && bucket.contains(element)` (null check chaining)
        // End missing code
    }

    /**
     * Get all elements of 'this' as a list.
     */
    public List<T> getElements() {
        // Add missing code here
        List<T> all = new ArrayList<>(getCount());
        for (List<T> bucket : storage) {
            if (bucket != null) {
                all.addAll(bucket);
            }
        }
        return all;
        // End missing code
    }

    /**
     * Add 'element' to 'this', if it is not contained in 'this' yet.
     * Throw IllegalArgumentException if 'element' is null.
     */
    public void add(T element) {
        // Add missing code here
        if (element == null) throw new IllegalArgumentException("The element is null");  // We don't accept null element
        // Remember page 7 of Lecture07.pdf?
        int bucketIndex = getIndex(element);  // Which bucket the element will go to?
        List<T> bucket = storage[bucketIndex];
        if (bucket == null) {
            // According to protocol 3 and 6, we shall now initialize the bucket
            // Also put the newly created bucket to the storage
            storage[bucketIndex] = bucket = new ArrayList<>();
            bucket.add(element);
        } else {
            // The bucket was already initiailzed, possibly non-empty
            // Now add the element if it is not in the bucket
            if (!bucket.contains(element)) bucket.add(element);
        }
        // End missing code
    }

    /**
     * Two CompSets are equivalent is they contain the same elements.
     * The order of the elements inside each CompSet is irrelevant.
     */
    @Override
    public boolean equals(Object other){
        // Add missing code here
        /* Two sets are equivalent if and only if:

        1) They have the same size, and
        2) For all elements in the first set are also in the second set
        */
        // Java cheat: check the object reference first
        if (this == other) return true;
        if (!(other instanceof CompSet)) return false;  // Type check

        // Java 16 comes with "JEP 394: Pattern Matching for instanceof" which can simplify this type-check-then-cast
        CompSet otherSet = (CompSet) other;
        if (otherSet.getCount() != getCount()) return false;  // Opps, not the same size (1)
        for (T element : getElements()) {
            if (!otherSet.contains(element)) {
                // Violation of rule 2
                return false;
            }
        }
        // All checks passed
        return true;
        // End of missing code
    }

    /**
     * Remove 'element' from 'this', if it is contained in 'this'.
     * Throw IllegalArgumentException if 'element' is null.
     */
    public void remove (T element) {
        // Add missing code here
        if (element == null) throw new IllegalArgumentException("Cannot remove a null element");
        // Again, similar accessing pattern
        int bucketIndex = getIndex(element);  // Which bucket the element will go to?
        List<T> bucket = storage[bucketIndex];
        if (bucket == null) return;  // It was never added, do nothing and return
        bucket.remove(element);
        /* According to the specification of `List.remove`, we can safely do this even
        if `element` is not in `bucket`
         */

        /* Here is an alternative implementation

        if(!contains(element)) return;
        storage[getIndex(element)].remove(element);

        This looks simpler, but it comes with redundant traversal
         */
        // End missing code
    }

    //========================================================================== private methods

    /**
     * Get the index of the bucket where the element should go
     * @param element the element to be accessed
     * @return the index of the owning bucket
     */
    private int getIndex(T element) {
        return element.hashCode() % NUBMER_OF_BUCKETS;
    }

}


