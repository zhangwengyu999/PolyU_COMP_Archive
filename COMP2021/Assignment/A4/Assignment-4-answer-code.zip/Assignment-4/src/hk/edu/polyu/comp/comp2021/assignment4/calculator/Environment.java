package hk.edu.polyu.comp.comp2021.assignment4.calculator;

import java.util.HashMap;

/**
 * An environment defining values for variables.
 */
public class Environment {
    /**
     * The actual place holding values for variables. For example:
     *
     * "foo" => 15
     * "g" => 27
     */
    private HashMap<String, Integer> storage;

    public Environment() {
        // Add missing code here
        storage = new HashMap<>();  // Init `storage`
        // End missing code
    }

    /**
     * Has 'variable' been defined in this environment?
     */
    public boolean hasDefined(Variable variable) {
        // Add missing code here
        return storage.containsKey(variable.getName());
        // End missing code
    }

    /**
     * Define 'variable' with 'value'.
     * Throw IllegalArgumentException if 'variable' is null or the variable has been defined in 'this' already.
     */
    public void defineVariable(Variable variable, int value) {
        // Add missing code here
        if (variable == null) {
            throw new IllegalArgumentException("Cannot define a null variable");
        }
        if (hasDefined(variable)) {
            throw new IllegalArgumentException("Cannot redefine variable " + variable.getName());
        }
        /* The above are essentially two types of exceptions.
        You don't want to mix null-pointer-like exception with name conflict, do you?
         */
        storage.put(variable.getName(), value);
        // End missing code
    }

    /**
     * Get the value of 'variable'.
     * Throw IllegalArgumentException if 'variable' is null or the variable is not defined in 'this'.
     */
    public int getValue(Variable variable) {
        // Add missing code here
        if (variable == null) {
            throw new IllegalArgumentException("Cannot get the value of null variable");
        }
        if (!hasDefined(variable)) {
            throw new IllegalArgumentException("Variable " + variable.getName() + " is undefined");
        }
        return storage.get(variable.getName());
        // End missing code
    }
}
