package hk.edu.polyu.comp.comp2021.assignment4.bankaccount;

/** A bank account object. */
public class BankAccount { 

    private int balance;

	/** Instantiate an account with 'initialBalance'. */
    public BankAccount(int initialBalance){
        if(initialBalance < 0)
            throw new IllegalArgumentException();

        balance = initialBalance;
    }

	/** Balance of the account. The balance should never be negative. */
    public int getBalance(){
        return balance;
    }

	/** Deposit 'amount' into this account. 'amount' should always be positive. */
    public void deposit(int amount) {
        if(amount <= 0)
            throw new IllegalArgumentException();

        // Add missing code here
        synchronized (this) {  // Lock the entire bank account for deposit
            // Start the deposit transaction
            balance += amount;
            // End the deposit transaction
            this.notifyAll();  // Tell everybody waiting for withdrawing, "please check the balance again"
        }
    }

	/**
     * Withdraw 'amount' from this account. 'amount' should always be positive.
     *
     * If the balance is insufficient, wait until it becomes sufficient
     * @param amount the amount of money to be withdrawn
     */
    public void withdraw(int amount) {
        if(amount <= 0)
            throw new IllegalArgumentException();

        // Add missing code here
        synchronized (this) {  // Lock the entire bank account for withdrawing
            // Wait until the balance is enough
            while (balance < amount) {  // If insufficient balance
                try {
                    wait();
                } catch (InterruptedException e) {
                    /* Do nothing */;  // Do not do this in practice - you might get an unstoppable dead-locked thread
                }
            }
            // Start the withdrawing transaction
            balance -= amount;
            // End the withdrawing transaction
        }
        // End missing code
    }
}
