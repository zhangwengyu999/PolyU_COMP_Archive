package hk.edu.polyu.comp.comp2021.assignment4.calculator;

/**
 * A variable expression.
 */
public class Variable extends Expression {
    private final String name;

    /**
     * Create a new variable with 'name'.
     * Throw IllegalArgumentException if 'name' is null or empty or 'name' contains other characters
     * than lower case English letters.
     */
    public Variable(String name) {
        // Add missing code here
        // If `name` is 1) null or 2) empty?
        if (name == null || name.isEmpty()) {
            /* In practice, you MUST clearly state what ON EARTH went wrong,
            preferably with custom exception that holds all contextual information.
            Otherwise, the project would become not debuggable.
             */
            throw new IllegalArgumentException("Null or empty variable name");
        }
        // 3) Or contains invalid chars?
        int size = name.length();
        for (int i = 0; i < size; i++) {
            char currentChar = name.charAt(i);  // Get and cache current name[i]
            if (currentChar < 'a' || 'z' < currentChar) {
                throw new IllegalArgumentException("Invalid character in the name of variable");
            }
        }
        // Alternatively, use Regular Expression for fast (development time) string format checking
        this.name = name;
        // End missing code
    }

    public String getName() {
        return name;
    }

    public String toString(){
        return getName();
    }

    /**
     * Return the value of 'this' as defined in 'env'.
     * Throw IllegalArgumentException if 'env' is null or 'this' is not defined in 'env'.
     */
    @Override
    public int evaluate(Environment env) {
        // Add missing code here
        if (env == null) {
            throw new IllegalArgumentException("Cannot evaluate with a null environment");
        }
        /* If this is not defined in `env`, `env.getValue` will throw an IllegalArgumentException.
        So, we don't do redundant checking here.
         */
        return env.getValue(this);
        // End missing code
    }


}
