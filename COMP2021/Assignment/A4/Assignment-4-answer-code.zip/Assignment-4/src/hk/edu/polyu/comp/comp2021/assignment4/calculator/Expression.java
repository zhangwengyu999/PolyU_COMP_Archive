package hk.edu.polyu.comp.comp2021.assignment4.calculator;

/**
 * An Expression.
 */
public abstract class Expression {
	/**
	 * Evaluate the expression w.r.t. given environment
	 *
	 * For different env, the result might also be different
	 * @param env the environment in which this expression is to be evaluated
	 * @return
	 */
	public abstract int evaluate(Environment env);
}
