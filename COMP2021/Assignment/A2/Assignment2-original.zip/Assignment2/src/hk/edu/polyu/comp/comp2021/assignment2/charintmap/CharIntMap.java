package hk.edu.polyu.comp.comp2021.assignment2.charintmap;

public class CharIntMap {

    private KeyValueEntry[] storage; // Internal storage of the map.

    private int count;// The number of key-value pairs currently stored in the map.

    public CharIntMap(int size) {
        // constructor
    }

    public int getValue(char key){
        // Return the value associated to the key
        // This method should only be called when containsKey(key) is true
        return 0;
    }

    public boolean isFull(){
        //Returns true if and only if the map contains the maximum number of keys.
        return false;
    }
    public boolean containsKey(char key) {
        // Returns true if and only if this map contains a mapping for the specified key.
        return false;
    }

    public boolean containsValue(int value) {
        // Returns true if and only if this map maps one or more keys to the specified value.
        return false;
    }

    public void put(char key, int value) {
        //Associates the specified value with the specified key in this map.
        //If the map previously contained a mapping for the key, the old value is replaced by the specified value
    }

    public void remove(char key) {
        // Removes the mapping for a key from this map if it is present

    }

    public void replace(char key, int value) {
        // Replaces the entry for the specified key if and only if it is currently mapped to some value.
    }


    public void merge(char key, int value){
        //If the specified key is not in this map, associates it with the given non-null value.
        //Otherwise, replaces the associated value with the addition of the associated value and the given non-null value.

    }

    public String keyString() {
        // Returns a String concatenated from the keys in this map
        return "";
    }

    public boolean hasSameKeys(CharIntMap map) {
        // Return true if and only if the keys of this map are exactly the same as those in the given map.
        return false;
    }

    // ==================================

}

class KeyValueEntry {

    private char key;

    private int value;

    KeyValueEntry(char key, int value) {

        this.key = key;

        this.value = value;

    }

    public char getKey() {

        return this.key;

    }

    public int getValue() {

        return this.value;

    }

    public void setValue(int val) {

        this.value = val;

    }
}

