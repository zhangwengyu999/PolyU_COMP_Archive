package hk.edu.polyu.comp.comp2021.assignment2.complex;

import org.omg.CORBA.CODESET_INCOMPATIBLE;

public class Complex {

    // Task 3: add the missing fields
    private Rational real;
    private Rational imag;

    public Complex(Rational real, Rational imag) {
        // Task 4: complete the constructor
    }

    public Complex add(Complex other) {
        // Task 4: complete the method
        return null;
    }

    public Complex subtract(Complex other) {
        // Task 4: complete the method
        return null;
    }

    public Complex multiply(Complex other) {
        // Task 4: complete the method
        return null;
    }

    public Complex divide(Complex other) {
        // Task 4: complete the method
        // you may assume 'other' is never equal to '0+/-0i'.
        return null;
    }

    public void simplify() {
        // Task 4L complete the method
    }

    public String toString() {
        // Task 4: complete the method
        return "";
    }

    // ==================================

}
