package hk.edu.polyu.comp.comp2021.assignment2.complex;

public class Rational {
    // Task 1: add the missing fields

    private int numerator;
    private int denominator;

    public Rational(int numerator, int denominator) {
        // Task 2: complete the constructor
    }

    public Rational add(Rational other) {
        // Task 2: complete the method
        return null;
    }

    public Rational subtract(Rational other) {
        // Task 2: complete the method
        return null;
    }

    public Rational multiply(Rational other) {
        // Task 2: complete the method
        return null;
    }

    public Rational divide(Rational other) {
        // Task 2: complete the method
        return null;
    }

    public String toString() {
        // Task 2: complete the method
        return "";
    }

    public void simplify() {
        // Task 2: complete the method
    }

    // ==================================

}
